Open android-release/index.html in a browser to browse the kit offline.
